var gallery;

window.onload = function () {
	var gallery = new ImageGallery("image_list", "image", "caption");
}